const API_URL = "http://localhost:8765/api/config";
const SKILLS_API_URL = "http://localhost:8765/api/skills";

const els = {
  provider: document.getElementById('provider'),
  endpoint: document.getElementById('endpoint'),
  apiKey: document.getElementById('apiKey'),
  modelId: document.getElementById('modelId'),
  systemPrompt: document.getElementById('systemPrompt'),
  saveBtn: document.getElementById('saveBtn'),
  statusMessage: document.getElementById('statusMessage'),
  
  // Tabs
  tabs: document.querySelectorAll('.tab'),
  tabContents: document.querySelectorAll('.tab-content'),
  
  // Skills
  skillsList: document.getElementById('skillsList'),
  newSkillBtn: document.getElementById('newSkillBtn'),
  skillEditor: document.getElementById('skillEditor'),
  skillEditorTitle: document.getElementById('skillEditorTitle'),
  skillId: document.getElementById('skillId'),
  skillName: document.getElementById('skillName'),
  skillDesc: document.getElementById('skillDesc'),
  skillPrompt: document.getElementById('skillPrompt'),
  saveSkillBtn: document.getElementById('saveSkillBtn'),
  cancelSkillBtn: document.getElementById('cancelSkillBtn')
};

// ───── Tabs ─────
els.tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    els.tabs.forEach(t => t.classList.remove('active'));
    els.tabContents.forEach(c => c.classList.remove('active'));
    
    tab.classList.add('active');
    document.getElementById(tab.dataset.target).classList.add('active');
    
    if (tab.dataset.target === 'tab-skills') {
      loadSkills();
    }
  });
});

// ───── AI Config ─────
async function loadConfig() {
  try {
    els.saveBtn.disabled = true;
    els.saveBtn.textContent = '加载中...';
    
    const response = await fetch(API_URL);
    if (!response.ok) throw new Error('Failed to load');
    
    const data = await response.json();
    if (data && data.ai) {
      els.provider.value = data.ai.provider || '';
      els.endpoint.value = data.ai.endpoint || '';
      els.apiKey.value = data.ai.apiKey || '';
      els.modelId.value = data.ai.modelId || '';
      els.systemPrompt.value = data.ai.systemPrompt || '';
    }
  } catch (err) {
    console.error(err);
    alert('无法连接到本地服务，请确保已启动 OfficeCopilot.Server.exe');
  } finally {
    els.saveBtn.disabled = false;
    els.saveBtn.textContent = '保存配置';
  }
}

async function saveConfig() {
  try {
    els.saveBtn.disabled = true;
    els.saveBtn.textContent = '保存中...';

    const payload = {
      ai: {
        provider: els.provider.value.trim(),
        endpoint: els.endpoint.value.trim(),
        apiKey: els.apiKey.value.trim(),
        modelId: els.modelId.value.trim(),
        systemPrompt: els.systemPrompt.value.trim()
      }
    };

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!response.ok) throw new Error('Failed to save');

    els.statusMessage.style.opacity = '1';
    setTimeout(() => { els.statusMessage.style.opacity = '0'; }, 2000);
  } catch (err) {
    console.error(err);
    alert('保存失败，请检查服务状态。');
  } finally {
    els.saveBtn.disabled = false;
    els.saveBtn.textContent = '保存配置';
  }
}

els.saveBtn.addEventListener('click', saveConfig);

// ───── Skills ─────
let currentSkills = [];

async function loadSkills() {
  try {
    const res = await fetch(SKILLS_API_URL);
    if (res.ok) {
      currentSkills = await res.json();
      renderSkills();
    }
  } catch (err) {
    console.error("Failed to load skills", err);
  }
}

function renderSkills() {
  if (currentSkills.length === 0) {
    els.skillsList.innerHTML = '<div style="text-align:center; padding: 20px; color:#999;">暂无自定义技能</div>';
    return;
  }
  
  els.skillsList.innerHTML = currentSkills.map(skill => `
    <div class="skill-card">
      <div class="skill-header">
        <div class="skill-title">${escapeHtml(skill.name)}</div>
        <div>
          <button class="btn-secondary" onclick="editSkill('${skill.id}')" style="padding: 4px 12px; font-size: 12px;">编辑</button>
          <button class="btn-danger" onclick="deleteSkill('${skill.id}')" style="padding: 4px 12px; font-size: 12px;">删除</button>
        </div>
      </div>
      <div class="skill-desc">${escapeHtml(skill.description)}</div>
      <div class="skill-prompt">${escapeHtml(skill.promptTemplate.substring(0, 100))}${skill.promptTemplate.length > 100 ? '...' : ''}</div>
    </div>
  `).join('');
}

window.editSkill = (id) => {
  const skill = currentSkills.find(s => s.id === id);
  if (!skill) return;
  
  els.skillId.value = skill.id;
  els.skillName.value = skill.name;
  els.skillDesc.value = skill.description;
  els.skillPrompt.value = skill.promptTemplate;
  
  els.skillEditorTitle.textContent = '编辑技能';
  els.skillEditor.style.display = 'block';
  els.skillsList.style.display = 'none';
  els.newSkillBtn.style.display = 'none';
};

window.deleteSkill = async (id) => {
  if (!confirm('确定要删除这个技能吗？')) return;
  try {
    const res = await fetch(`${SKILLS_API_URL}/${id}`, { method: 'DELETE' });
    if (res.ok) await loadSkills();
  } catch (err) {
    alert('删除失败');
  }
};

els.newSkillBtn.addEventListener('click', () => {
  els.skillId.value = '';
  els.skillName.value = '';
  els.skillDesc.value = '';
  els.skillPrompt.value = '';
  
  els.skillEditorTitle.textContent = '新增技能';
  els.skillEditor.style.display = 'block';
  els.skillsList.style.display = 'none';
  els.newSkillBtn.style.display = 'none';
});

els.cancelSkillBtn.addEventListener('click', () => {
  els.skillEditor.style.display = 'none';
  els.skillsList.style.display = 'block';
  els.newSkillBtn.style.display = 'block';
});

els.saveSkillBtn.addEventListener('click', async () => {
  const payload = {
    id: els.skillId.value,
    name: els.skillName.value.trim(),
    description: els.skillDesc.value.trim(),
    promptTemplate: els.skillPrompt.value.trim()
  };
  
  if (!payload.name || !payload.promptTemplate) {
    alert('技能名称和处理逻辑不能为空');
    return;
  }
  
  try {
    els.saveSkillBtn.disabled = true;
    const res = await fetch(SKILLS_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    
    if (res.ok) {
      els.skillEditor.style.display = 'none';
      els.skillsList.style.display = 'block';
      els.newSkillBtn.style.display = 'block';
      await loadSkills();
    }
  } catch (err) {
    alert('保存失败');
  } finally {
    els.saveSkillBtn.disabled = false;
  }
});

function escapeHtml(unsafe) {
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
}

// ───── Boot ─────
document.addEventListener('DOMContentLoaded', loadConfig);

// ───── MCP ─────
function renderMcpList(mcps) {
  const listEl = document.getElementById('mcpList');
  if (!mcps || mcps.length === 0) {
    listEl.innerHTML = '<div style="text-align:center; padding: 20px; color:#999;">暂无外部 MCP 组件</div>';
    return;
  }
  
  listEl.innerHTML = mcps.map(mcp => `
    <div class="skill-card">
      <div class="skill-header">
        <div class="skill-title">🔌 ${escapeHtml(mcp.name)}</div>
        <div>
          <button class="btn-secondary" onclick="editMcp('${mcp.id}')" style="padding: 4px 12px; font-size: 12px;">编辑</button>
          <button class="btn-danger" onclick="deleteMcp('${mcp.id}')" style="padding: 4px 12px; font-size: 12px;">删除</button>
        </div>
      </div>
      <div class="skill-desc">
        <code>${escapeHtml(mcp.command)} ${escapeHtml(mcp.args.join(' '))}</code>
      </div>
    </div>
  `).join('');
}

let fullConfig = null;

async function loadConfig() {
  try {
    els.saveBtn.disabled = true;
    els.saveBtn.textContent = '加载中...';
    
    const response = await fetch(API_URL);
    if (!response.ok) throw new Error('Failed to load');
    
    fullConfig = await response.json();
    const data = fullConfig;
    if (data && data.ai) {
      els.provider.value = data.ai.provider || '';
      els.endpoint.value = data.ai.endpoint || '';
      els.apiKey.value = data.ai.apiKey || '';
      els.modelId.value = data.ai.modelId || '';
      els.systemPrompt.value = data.ai.systemPrompt || '';
    }
    
    renderMcpList(data.mcpServers || []);
    
  } catch (err) {
    console.error(err);
    alert('无法连接到本地服务，请确保已启动 OfficeCopilot.Server.exe');
  } finally {
    els.saveBtn.disabled = false;
    els.saveBtn.textContent = '保存配置';
  }
}

document.getElementById('newMcpBtn').addEventListener('click', () => {
  document.getElementById('mcpId').value = '';
  document.getElementById('mcpName').value = '';
  document.getElementById('mcpCommand').value = '';
  document.getElementById('mcpArgs').value = '';
  
  document.getElementById('mcpEditorTitle').textContent = '新增 MCP 组件';
  document.getElementById('mcpEditor').style.display = 'block';
  document.getElementById('mcpList').style.display = 'none';
  document.getElementById('newMcpBtn').style.display = 'none';
});

document.getElementById('cancelMcpBtn').addEventListener('click', () => {
  document.getElementById('mcpEditor').style.display = 'none';
  document.getElementById('mcpList').style.display = 'block';
  document.getElementById('newMcpBtn').style.display = 'block';
});

window.editMcp = (id) => {
  if (!fullConfig || !fullConfig.mcpServers) return;
  const mcp = fullConfig.mcpServers.find(s => s.id === id);
  if (!mcp) return;
  
  document.getElementById('mcpId').value = mcp.id;
  document.getElementById('mcpName').value = mcp.name;
  document.getElementById('mcpCommand').value = mcp.command;
  document.getElementById('mcpArgs').value = (mcp.args || []).join('\n');
  
  document.getElementById('mcpEditorTitle').textContent = '编辑 MCP 组件';
  document.getElementById('mcpEditor').style.display = 'block';
  document.getElementById('mcpList').style.display = 'none';
  document.getElementById('newMcpBtn').style.display = 'none';
};

window.deleteMcp = async (id) => {
  if (!confirm('确定要删除这个组件吗？')) return;
  
  fullConfig.mcpServers = fullConfig.mcpServers.filter(s => s.id !== id);
  await _saveFullConfig();
};

document.getElementById('saveMcpBtn').addEventListener('click', async () => {
  const id = document.getElementById('mcpId').value || crypto.randomUUID().replace(/-/g, '');
  const name = document.getElementById('mcpName').value.trim();
  const cmd = document.getElementById('mcpCommand').value.trim();
  const args = document.getElementById('mcpArgs').value.split('\n').map(a => a.trim()).filter(a => a);
  
  if (!name || !cmd) {
    alert('名称和启动命令不能为空');
    return;
  }
  
  if (!fullConfig.mcpServers) fullConfig.mcpServers = [];
  
  const existingIdx = fullConfig.mcpServers.findIndex(s => s.id === id);
  const newMcp = { id, name, command: cmd, args };
  
  if (existingIdx >= 0) {
    fullConfig.mcpServers[existingIdx] = newMcp;
  } else {
    fullConfig.mcpServers.push(newMcp);
  }
  
  await _saveFullConfig();
  
  document.getElementById('mcpEditor').style.display = 'none';
  document.getElementById('mcpList').style.display = 'block';
  document.getElementById('newMcpBtn').style.display = 'block';
});

async function _saveFullConfig() {
  try {
    const payload = {
      ai: {
        provider: els.provider.value.trim(),
        endpoint: els.endpoint.value.trim(),
        apiKey: els.apiKey.value.trim(),
        modelId: els.modelId.value.trim(),
        systemPrompt: els.systemPrompt.value.trim()
      },
      mcpServers: fullConfig.mcpServers || []
    };

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!response.ok) throw new Error('Failed to save');
    await loadConfig();
  } catch (err) {
    console.error(err);
    alert('保存失败');
  }
}
