const WS_URL = "ws://localhost:8765/ws";
const AUTH_TOKEN = "office-copilot-dev-token";

const RECONNECT_BASE_MS = 1000;
const RECONNECT_MAX_MS = 16000;

const $messages = document.getElementById("messages");
const $input = document.getElementById("input");
const $sendBtn = document.getElementById("send-btn");
const $status = document.getElementById("status");
const $settingsBtn = document.getElementById("settings-btn");

if ($settingsBtn) {
  $settingsBtn.addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
}

let ws = null;
let sessionId = null;
let reconnectDelay = RECONNECT_BASE_MS;
let reconnectTimer = null;
let streamingBubble = null;

// ───── Session ID ─────

function getSessionId() {
  let id = sessionStorage.getItem("copilot_session_id");
  if (!id) {
    id = crypto.randomUUID().replace(/-/g, "").slice(0, 12);
    sessionStorage.setItem("copilot_session_id", id);
  }
  return id;
}

// ───── WebSocket ─────

function connect() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }

  sessionId = getSessionId();
  const url = `${WS_URL}?sessionId=${sessionId}&token=${AUTH_TOKEN}`;
  ws = new WebSocket(url);

  ws.addEventListener("open", () => {
    reconnectDelay = RECONNECT_BASE_MS;
    setStatus(true);
    addSystemMessage("已连接到本地服务");
  });

  ws.addEventListener("message", (e) => {
    handleMessage(e.data);
  });

  ws.addEventListener("close", () => {
    setStatus(false);
    finalizeStream();
    scheduleReconnect();
  });

  ws.addEventListener("error", () => {
    ws.close();
  });
}

function scheduleReconnect() {
  if (reconnectTimer) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    reconnectDelay = Math.min(reconnectDelay * 2, RECONNECT_MAX_MS);
    connect();
  }, reconnectDelay);
}

function send(text) {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  const payload = JSON.stringify({ type: "text", content: text });
  ws.send(payload);
}

// ───── Streaming state ─────

function beginStream() {
  streamingBubble = appendMsg("msg--bot msg--streaming", "");
  setInputEnabled(false);
}

function appendStreamChunk(text) {
  if (!streamingBubble) {
    beginStream();
  }
  streamingBubble.textContent += text;
  $messages.scrollTop = $messages.scrollHeight;
}

function finalizeStream() {
  if (streamingBubble) {
    streamingBubble.classList.remove("msg--streaming");
    streamingBubble = null;
  }
  setInputEnabled(true);
}

// ───── Message handling ─────

function handleMessage(raw) {
  let msg;
  try {
    msg = JSON.parse(raw);
  } catch {
    msg = { type: "text", content: raw };
  }

  switch (msg.type) {
    case "stream_start":
      beginStream();
      break;

    case "stream_chunk":
      appendStreamChunk(msg.content);
      break;

    case "stream_end":
      finalizeStream();
      extractAndRenderCanvas();
      break;

    case "echo":
    case "text":
      addBotMessage(msg.content);
      break;

    case "pong":
      break;

    case "error":
      finalizeStream();
      addBotMessage(`⚠️ ${msg.content}`);
      break;

    default:
      addBotMessage(msg.content || JSON.stringify(msg));
  }
}

// ───── Canvas Rendering ─────
function extractAndRenderCanvas() {
  const msgs = document.querySelectorAll('.msg--bot');
  if (msgs.length === 0) return;
  const lastMsg = msgs[msgs.length - 1];
  const text = lastMsg.textContent;
  
  const startIdx = text.indexOf('<html_canvas>');
  const endIdx = text.indexOf('</html_canvas>');
  
  if (startIdx !== -1 && endIdx !== -1 && endIdx > startIdx) {
    const htmlCode = text.substring(startIdx + 13, endIdx).trim();
    // 隐藏原始代码文本
    const displayHtml = lastMsg.innerHTML.replace(/<html_canvas>[\s\S]*?<\/html_canvas>/g, '<i>[交互式图表已生成在下方展示板]</i>');
    lastMsg.innerHTML = displayHtml;
    
    renderCanvas(htmlCode);
  }
}

function renderCanvas(htmlCode) {
  let container = document.getElementById('canvas-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'canvas-container';
    container.className = 'canvas-container';
    document.getElementById('messages').appendChild(container);
  } else {
    // 移到最新消息下面
    document.getElementById('messages').appendChild(container);
  }
  
  container.innerHTML = `
    <div class="canvas-header">
      <span>📊 数据展示板</span>
      <button onclick="document.getElementById('canvas-container').style.display='none'">关闭</button>
    </div>
    <iframe sandbox="allow-scripts" class="canvas-frame"></iframe>
  `;
  container.style.display = 'flex';
  
  const iframe = container.querySelector('iframe');
  iframe.srcdoc = htmlCode;
  $messages.scrollTop = $messages.scrollHeight;
}

// ───── UI helpers ─────

function addUserMessage(text) {
  appendMsg("msg--user", text);
}

function addBotMessage(text) {
  appendMsg("msg--bot", text);
}

function addSystemMessage(text) {
  appendMsg("msg--system", text);
}

function appendMsg(cls, text) {
  const welcome = $messages.querySelector(".welcome");
  if (welcome) welcome.remove();

  const div = document.createElement("div");
  div.className = `msg ${cls}`;
  div.textContent = text;
  $messages.appendChild(div);
  $messages.scrollTop = $messages.scrollHeight;
  return div;
}

function setStatus(connected) {
  $status.className = connected ? "status status--connected" : "status status--disconnected";
  $status.querySelector(".status-text").textContent = connected ? "已连接" : "未连接";
}

function setInputEnabled(enabled) {
  $input.disabled = !enabled;
  $sendBtn.disabled = !enabled;
  if (enabled) $input.focus();
}

// ───── Input handling ─────

function handleSend() {
  const text = $input.value.trim();
  if (!text) return;
  if (streamingBubble) return;

  addUserMessage(text);
  send(text);
  $input.value = "";
  $input.style.height = "auto";
  $input.focus();
}

$sendBtn.addEventListener("click", handleSend);

$input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    handleSend();
  }
});

$input.addEventListener("input", () => {
  $input.style.height = "auto";
  $input.style.height = Math.min($input.scrollHeight, 120) + "px";
});

// ───── Boot ─────

connect();
